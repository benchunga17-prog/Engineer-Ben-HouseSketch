# HouseSketch does not require custom ProGuard rules in v1.
