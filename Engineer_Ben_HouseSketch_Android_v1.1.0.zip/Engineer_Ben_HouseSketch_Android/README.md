# Engineer Ben HouseSketch — Android App v1.0.0

A native Android application wrapper around the Engineer Ben HouseSketch drawing engine.

## Included
- Android Studio project
- Native Android launcher/activity
- Offline local HTML/SVG drawing engine bundled in app assets
- Engineer Ben branding
- Room, wall, door, window and label tools
- 3-bedroom template
- Smart brief starter
- Undo/redo
- Local project saving
- PNG/SVG/print-to-PDF export from the drawing engine
- A4/A3 drawing sheet selection
- Structural columns, beams and grid bubbles
- Professional Engineer Ben title block with email
- Portrait/landscape support
- Minimum Android 7.0 (API 24)

## Open and build
1. Install Android Studio (current stable).
2. Open this folder: `Engineer_Ben_HouseSketch_Android`.
3. Let Gradle sync and install the Android SDK platform/build tools requested by Android Studio.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Run the `app` configuration.
6. For a release APK: Build > Generate App Bundles or APKs > Generate APKs.

The project uses Android Gradle Plugin 9.4.1 and Gradle 9.6.0-compatible configuration. If Android Studio proposes an automatic Gradle/AGP update, accept it when appropriate.

## Package
`ke.co.engineerben.housesketch`

## Version
1.1.0 (versionCode 2)

## Important
HouseSketch is a planning/sketching aid. It is not a replacement for structural calculations, code compliance, professional review, or signed construction drawings.
