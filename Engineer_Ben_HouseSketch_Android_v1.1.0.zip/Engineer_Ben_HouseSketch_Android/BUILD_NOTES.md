# Android build notes

This environment does not contain the Android SDK, so an APK was not compiled here. The delivered project is an Android Studio-ready source project. Open it in Android Studio, allow the requested SDK components to install, then Run or Generate APK.

Current Android tooling reference: Android Gradle Plugin 9.4.x is the current stable line in September 2026; the project pins 9.4.1. See Android Developers release notes for compatibility details.
